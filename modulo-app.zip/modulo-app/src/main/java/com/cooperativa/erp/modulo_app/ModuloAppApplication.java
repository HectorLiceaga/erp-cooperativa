package com.cooperativa.erp.modulo_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModuloAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModuloAppApplication.class, args);
	}

}
